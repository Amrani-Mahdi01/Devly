import fetch from "node-fetch";

export default async function () {
  try {
    const body = JSON.parse(process.env.APPWRITE_FUNCTION_EVENT_DATA);

    const message = `
📩 New Contact Message

👤 Name: ${body.fullName}
📧 Email: ${body.email}
📞 Phone: ${body.phone}
📌 Subject: ${body.subject}

📝 Message:
${body.message}
    `;

    await fetch(
      `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: process.env.TELEGRAM_CHAT_ID,
          text: message,
        }),
      }
    );

    console.log("Message sent successfully!");
    return { success: true };
  } catch (err) {
    console.error("Error sending Telegram message:", err);
    return { success: false, error: err.message };
  }
}
